import nodemailer from 'nodemailer';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Create email transporter
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: process.env.SMTP_PORT,
  secure: false,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

// Email configuration
const mailOptions = {
  from: process.env.EMAIL_USER,
  to: 'mageleif@yahoo.com',
  subject: 'Test Email from Node.js',
  text: 'This is a test email sent from Node.js using nodemailer.',
  html: '<h1>Test Email</h1><p>This is a test email sent from Node.js using nodemailer.</p>'
};

// Send email
async function sendEmail() {
  try {
    const info = await transporter.sendMail(mailOptions);
    console.log('Email sent successfully!');
    console.log('Message ID:', info.messageId);
  } catch (error) {
    console.error('Error sending email:', error);
  }
}

// Execute the send email function
sendEmail();
